import Link from 'next/link'

export default function Annexes() {
  return (
    <main className="flex min-h-screen flex-col items-center p-8 md:p-24">
      <div className="max-w-5xl w-full">
        <nav className="mb-8">
          <Link href="/" className="text-blue-600 hover:underline">
            ← Retour à l'accueil
          </Link>
        </nav>
        
        <h1 className="text-3xl font-bold mb-8">Annexes</h1>
        
        <div className="prose max-w-none">
          <h2 className="text-2xl font-semibold mt-8 mb-4">Annexe 1 : Glossaire des termes techniques</h2>
          
          <div className="overflow-x-auto mb-8">
            <table className="min-w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 px-4 py-2">Terme</th>
                  <th className="border border-gray-300 px-4 py-2">Définition</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-gray-300 px-4 py-2 font-medium">Sedex</td>
                  <td className="border border-gray-300 px-4 py-2">Secure Data Exchange, infrastructure nationale suisse d'échange sécurisé de données</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2 font-medium">SedexID</td>
                  <td className="border border-gray-300 px-4 py-2">Identifiant unique attribué à chaque participant au réseau Sedex</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 px-4 py-2 font-medium">RAFAM</td>
                  <td className="border border-gray-300 px-4 py-2">Registre des Allocations Familiales</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2 font-medium">CdC</td>
                  <td className="border border-gray-300 px-4 py-2">Centrale de Compensation</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 px-4 py-2 font-medium">UPI</td>
                  <td className="border border-gray-300 px-4 py-2">Unique Person Identification, système de gestion des numéros AVS</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2 font-medium">OFAS</td>
                  <td className="border border-gray-300 px-4 py-2">Office Fédéral des Assurances Sociales</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 px-4 py-2 font-medium">iPension/WebAVS</td>
                  <td className="border border-gray-300 px-4 py-2">Systèmes informatiques utilisés par les caisses de compensation</td>
                </tr>
              </tbody>
            </table>
          </div>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Annexe 2 : Références documentaires</h2>
          
          <ul className="list-disc pl-6 mb-8">
            <li className="mb-2">Directives techniques Sedex de l'OFAS</li>
            <li className="mb-2">Normes eCH pour les échanges de données (eCH-0058, eCH-0085)</li>
            <li className="mb-2">Documentation technique iPension/WebAVS</li>
            <li className="mb-2">Réglementation sur les allocations familiales</li>
          </ul>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Annexe 3 : Liste des documents produits</h2>
          
          <ol className="list-decimal pl-6 mb-8">
            <li className="mb-2">Analyse du contexte de fusion des caisses de compensation</li>
            <li className="mb-2">Documentation des flux de données Sedex existants</li>
            <li className="mb-2">Cartographie des échanges de données</li>
            <li className="mb-2">Plan de migration détaillé</li>
            <li className="mb-2">Plan de retour en arrière</li>
            <li className="mb-2">Procédures manuelles temporaires</li>
            <li className="mb-2">Identification des périodes critiques</li>
          </ol>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Annexe 4 : Exemple de message XML Sedex</h2>
          
          <div className="bg-gray-100 p-4 rounded-lg mb-8 overflow-x-auto">
            <pre className="text-xs md:text-sm">
{`<?xml version="1.0" encoding="UTF-8"?>
<eCH-0058:delivery xmlns:eCH-0058="http://www.ech.ch/xmlns/eCH-0058/5">
  <eCH-0058:deliveryHeader>
    <eCH-0058:messageId>A2021-0000123456</eCH-0058:messageId>
    <eCH-0058:messageType>2056</eCH-0058:messageType>
    <eCH-0058:senderId>sedex://T4-123456</eCH-0058:senderId>
    <eCH-0058:recipientId>sedex://T3-654321</eCH-0058:recipientId>
    <eCH-0058:eventDate>2025-03-15</eCH-0058:eventDate>
    <eCH-0058:messageDate>2025-03-15T10:23:45</eCH-0058:messageDate>
    <eCH-0058:action>1</eCH-0058:action>
    <eCH-0058:testDeliveryFlag>0</eCH-0058:testDeliveryFlag>
  </eCH-0058:deliveryHeader>
  <eCH-0058:deliveryPayload>
    <allocation>
      <allocationId>AF2025-12345</allocationId>
      <beneficiary>
        <navs13>7561234567890</navs13>
        <firstName>Jean</firstName>
        <lastName>Dupont</lastName>
        <birthDate>1985-06-15</birthDate>
      </beneficiary>
      <child>
        <navs13>7567890123456</navs13>
        <firstName>Marie</firstName>
        <lastName>Dupont</lastName>
        <birthDate>2020-03-10</birthDate>
      </child>
      <allocationAmount>300.00</allocationAmount>
      <currency>CHF</currency>
      <validFrom>2025-04-01</validFrom>
      <validTo>2045-03-31</validTo>
    </allocation>
  </eCH-0058:deliveryPayload>
</eCH-0058:delivery>`}
            </pre>
          </div>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Annexe 5 : Contacts clés</h2>
          
          <div className="overflow-x-auto mb-8">
            <table className="min-w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 px-4 py-2">Organisation</th>
                  <th className="border border-gray-300 px-4 py-2">Service</th>
                  <th className="border border-gray-300 px-4 py-2">Contact</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-gray-300 px-4 py-2">OFAS</td>
                  <td className="border border-gray-300 px-4 py-2">Service Sedex</td>
                  <td className="border border-gray-300 px-4 py-2">sedex@ofas.admin.ch</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2">RAFAM</td>
                  <td className="border border-gray-300 px-4 py-2">Support technique</td>
                  <td className="border border-gray-300 px-4 py-2">support@rafam.ch</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 px-4 py-2">CdC</td>
                  <td className="border border-gray-300 px-4 py-2">Service UPI</td>
                  <td className="border border-gray-300 px-4 py-2">upi@cdc.admin.ch</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2">iPension</td>
                  <td className="border border-gray-300 px-4 py-2">Support client</td>
                  <td className="border border-gray-300 px-4 py-2">support@ipension.ch</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        
        <div className="mt-12 flex justify-between">
          <Link href="/sections/conclusion" className="text-blue-600 hover:underline">
            ← Conclusion
          </Link>
          <Link href="/" className="text-blue-600 hover:underline">
            Retour à l'accueil
          </Link>
        </div>
      </div>
    </main>
  )
}
