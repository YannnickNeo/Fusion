import Link from 'next/link'
import Image from 'next/image'

export default function FluxDonnees() {
  return (
    <main className="flex min-h-screen flex-col items-center p-8 md:p-24">
      <div className="max-w-5xl w-full">
        <nav className="mb-8">
          <Link href="/" className="text-blue-600 hover:underline">
            ← Retour à l'accueil
          </Link>
        </nav>
        
        <h1 className="text-3xl font-bold mb-8">Documentation des flux de données Sedex existants</h1>
        
        <div className="prose max-w-none">
          <h2 className="text-2xl font-semibold mt-8 mb-4">Qu'est-ce que Sedex?</h2>
          <p className="mb-4">
            Sedex (Secure Data Exchange) est l'infrastructure nationale suisse d'échange sécurisé de données entre 
            les institutions de sécurité sociale. Chaque institution participant à ce réseau possède un identifiant 
            unique (SedexID) qui permet d'authentifier et de router correctement les messages échangés.
          </p>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Flux de données principaux utilisant les identifiants Sedex</h2>
          
          <h3 className="text-xl font-medium mt-6 mb-3">1. Échanges avec le Registre des Allocations Familiales (RAFAM)</h3>
          <p className="mb-4">
            Ces échanges comprennent :
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>Annonces de nouvelles allocations (Caisse → RAFAM)</li>
            <li>Modifications d'allocations existantes (Caisse → RAFAM)</li>
            <li>Fin d'allocations (Caisse → RAFAM)</li>
            <li>Vérifications de droit (RAFAM → Caisse)</li>
            <li>Réponses aux vérifications (Caisse → RAFAM)</li>
          </ul>
          <p className="mb-4">
            Les messages sont structurés en XML selon le schéma eCH-0058, et contiennent systématiquement le SedexID 
            de l'émetteur, permettant au RAFAM d'identifier la caisse d'origine.
          </p>
          
          <h3 className="text-xl font-medium mt-6 mb-3">2. Échanges avec la Centrale de Compensation (CdC)</h3>
          <p className="mb-4">
            Ces échanges comprennent :
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>Vérification des numéros AVS (Caisse → CdC)</li>
            <li>Réponses aux vérifications AVS (CdC → Caisse)</li>
          </ul>
          <p className="mb-4">
            Les messages suivent le format eCH-0085 et sont essentiels pour valider l'identité des allocataires et des enfants.
          </p>
          
          <h3 className="text-xl font-medium mt-6 mb-3">3. Échanges avec l'Office Fédéral des Assurances Sociales (OFAS)</h3>
          <p className="mb-4">
            Ces échanges comprennent principalement les rapports statistiques trimestriels ou annuels sur les allocations familiales.
          </p>
          
          <h3 className="text-xl font-medium mt-6 mb-3">4. Échanges entre caisses de compensation</h3>
          <p className="mb-4">
            Ces échanges concernent principalement les transferts de dossiers lors d'un changement d'affiliation.
          </p>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Fréquence et volume des échanges</h2>
          <div className="overflow-x-auto mb-6">
            <table className="min-w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 px-4 py-2">Type d'échange</th>
                  <th className="border border-gray-300 px-4 py-2">Fréquence</th>
                  <th className="border border-gray-300 px-4 py-2">Volume estimé (caisse moyenne)</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-gray-300 px-4 py-2">Nouvelles allocations</td>
                  <td className="border border-gray-300 px-4 py-2">Temps réel</td>
                  <td className="border border-gray-300 px-4 py-2">50-100 par jour</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2">Modifications</td>
                  <td className="border border-gray-300 px-4 py-2">Temps réel</td>
                  <td className="border border-gray-300 px-4 py-2">20-50 par jour</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 px-4 py-2">Fins d'allocations</td>
                  <td className="border border-gray-300 px-4 py-2">Temps réel</td>
                  <td className="border border-gray-300 px-4 py-2">10-30 par jour</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2">Vérifications de droit</td>
                  <td className="border border-gray-300 px-4 py-2">Temps réel</td>
                  <td className="border border-gray-300 px-4 py-2">30-80 par jour</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 px-4 py-2">Vérifications AVS</td>
                  <td className="border border-gray-300 px-4 py-2">Temps réel/batch</td>
                  <td className="border border-gray-300 px-4 py-2">50-200 par jour</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2">Rapports statistiques</td>
                  <td className="border border-gray-300 px-4 py-2">Trimestriel/Annuel</td>
                  <td className="border border-gray-300 px-4 py-2">1-4 par an</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 px-4 py-2">Transferts de dossiers</td>
                  <td className="border border-gray-300 px-4 py-2">À la demande</td>
                  <td className="border border-gray-300 px-4 py-2">5-20 par mois</td>
                </tr>
              </tbody>
            </table>
          </div>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Implications pour la fusion des caisses</h2>
          <p className="mb-4">
            La documentation des flux de données Sedex existants révèle plusieurs points critiques à considérer lors de la fusion des caisses :
          </p>
          
          <ol className="list-decimal pl-6 mb-6">
            <li className="mb-2"><strong>Identification unique</strong> : Chaque message Sedex contient le SedexID de l'émetteur, ce qui permet au destinataire d'identifier la caisse d'origine.</li>
            <li className="mb-2"><strong>Routage des messages</strong> : Le RAFAM et les autres partenaires utilisent le SedexID pour router les messages vers la bonne caisse.</li>
            <li className="mb-2"><strong>Historique des échanges</strong> : Les messages précédemment échangés font référence à l'ancien SedexID.</li>
            <li className="mb-2"><strong>Continuité de service</strong> : Les échanges en temps réel ne doivent pas être interrompus pendant la migration.</li>
            <li className="mb-2"><strong>Synchronisation des systèmes</strong> : Les systèmes iPension/WebAVS doivent être configurés pour utiliser le bon SedexID.</li>
          </ol>
        </div>
        
        <div className="mt-12 flex justify-between">
          <Link href="/sections/analyse-contexte" className="text-blue-600 hover:underline">
            ← Analyse du contexte
          </Link>
          <Link href="/sections/cartographie" className="text-blue-600 hover:underline">
            Cartographie des échanges de données →
          </Link>
        </div>
      </div>
    </main>
  )
}
