import Link from 'next/link'

export default function ProceduresManuelles() {
  return (
    <main className="flex min-h-screen flex-col items-center p-8 md:p-24">
      <div className="max-w-5xl w-full">
        <nav className="mb-8">
          <Link href="/" className="text-blue-600 hover:underline">
            ← Retour à l'accueil
          </Link>
        </nav>
        
        <h1 className="text-3xl font-bold mb-8">Procédures manuelles temporaires</h1>
        
        <div className="prose max-w-none">
          <h2 className="text-2xl font-semibold mt-8 mb-4">Objectifs des procédures manuelles</h2>
          <p className="mb-4">
            Les procédures manuelles temporaires visent à :
          </p>
          
          <ol className="list-decimal pl-6 mb-6">
            <li className="mb-2"><strong>Assurer la continuité de service</strong> : Garantir que les allocations sont traitées sans interruption</li>
            <li className="mb-2"><strong>Maintenir la conformité réglementaire</strong> : Respecter les obligations légales</li>
            <li className="mb-2"><strong>Sécuriser les échanges critiques</strong> : Prioriser les échanges les plus importants</li>
            <li className="mb-2"><strong>Faciliter la transition</strong> : Permettre une migration progressive sans impact</li>
          </ol>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Identification des échanges critiques</h2>
          <p className="mb-4">
            Quatre types d'échanges sont identifiés comme critiques et nécessitent des procédures manuelles de secours :
          </p>
          
          <div className="overflow-x-auto mb-6">
            <table className="min-w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 px-4 py-2">Type d'échange</th>
                  <th className="border border-gray-300 px-4 py-2">Niveau de criticité</th>
                  <th className="border border-gray-300 px-4 py-2">Délai maximal acceptable</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-gray-300 px-4 py-2">Annonces au RAFAM</td>
                  <td className="border border-gray-300 px-4 py-2">Très haute</td>
                  <td className="border border-gray-300 px-4 py-2">24 heures</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2">Vérifications de droit auprès du RAFAM</td>
                  <td className="border border-gray-300 px-4 py-2">Haute</td>
                  <td className="border border-gray-300 px-4 py-2">48 heures</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 px-4 py-2">Vérifications des numéros AVS</td>
                  <td className="border border-gray-300 px-4 py-2">Moyenne</td>
                  <td className="border border-gray-300 px-4 py-2">72 heures</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2">Transferts de dossiers entre caisses</td>
                  <td className="border border-gray-300 px-4 py-2">Moyenne</td>
                  <td className="border border-gray-300 px-4 py-2">1 semaine</td>
                </tr>
              </tbody>
            </table>
          </div>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Procédures manuelles par type d'échange</h2>
          
          <h3 className="text-xl font-medium mt-6 mb-3">1. Annonces au RAFAM</h3>
          <div className="bg-blue-50 p-6 rounded-lg mb-6">
            <h4 className="text-lg font-medium mb-3">Procédure de secours</h4>
            <ol className="list-decimal pl-6">
              <li className="mb-2"><strong>Déclenchement</strong> : Échec de transmission électronique pendant plus de 4 heures</li>
              <li className="mb-2"><strong>Formulaire</strong> : Utilisation du formulaire standardisé "RAFAM-SEC-01"</li>
              <li className="mb-2"><strong>Transmission</strong> : Envoi par email sécurisé au contact dédié du RAFAM</li>
              <li className="mb-2"><strong>Suivi</strong> : Enregistrement dans le registre manuel des annonces</li>
              <li className="mb-2"><strong>Régularisation</strong> : Transmission électronique dès rétablissement du service</li>
            </ol>
          </div>
          
          <h3 className="text-xl font-medium mt-6 mb-3">2. Vérifications de droit auprès du RAFAM</h3>
          <div className="bg-blue-50 p-6 rounded-lg mb-6">
            <h4 className="text-lg font-medium mb-3">Procédure de secours</h4>
            <ol className="list-decimal pl-6">
              <li className="mb-2"><strong>Déclenchement</strong> : Absence de réponse électronique pendant plus de 24 heures</li>
              <li className="mb-2"><strong>Formulaire</strong> : Utilisation du formulaire standardisé "RAFAM-SEC-02"</li>
              <li className="mb-2"><strong>Transmission</strong> : Envoi par email sécurisé et confirmation téléphonique</li>
              <li className="mb-2"><strong>Traitement provisoire</strong> : Décision conditionnelle basée sur les informations disponibles</li>
              <li className="mb-2"><strong>Régularisation</strong> : Ajustement de la décision après réception de la réponse officielle</li>
            </ol>
          </div>
          
          <h3 className="text-xl font-medium mt-6 mb-3">3. Vérifications des numéros AVS</h3>
          <div className="bg-blue-50 p-6 rounded-lg mb-6">
            <h4 className="text-lg font-medium mb-3">Procédure de secours</h4>
            <ol className="list-decimal pl-6">
              <li className="mb-2"><strong>Déclenchement</strong> : Échec de vérification électronique pendant plus de 48 heures</li>
              <li className="mb-2"><strong>Alternative</strong> : Utilisation du portail web UPI de la CdC avec authentification renforcée</li>
              <li className="mb-2"><strong>Documentation</strong> : Capture d'écran des résultats de vérification</li>
              <li className="mb-2"><strong>Limitation</strong> : Procédure limitée à 20 vérifications par jour</li>
              <li className="mb-2"><strong>Régularisation</strong> : Confirmation via le canal standard dès rétablissement</li>
            </ol>
          </div>
          
          <h3 className="text-xl font-medium mt-6 mb-3">4. Transferts de dossiers entre caisses</h3>
          <div className="bg-blue-50 p-6 rounded-lg mb-6">
            <h4 className="text-lg font-medium mb-3">Procédure de secours</h4>
            <ol className="list-decimal pl-6">
              <li className="mb-2"><strong>Déclenchement</strong> : Impossibilité de transfert électronique pendant plus de 72 heures</li>
              <li className="mb-2"><strong>Formulaire</strong> : Utilisation du formulaire standardisé "INTER-CAF-01"</li>
              <li className="mb-2"><strong>Transmission</strong> : Envoi par email sécurisé avec accusé de réception</li>
              <li className="mb-2"><strong>Coordination</strong> : Contact téléphonique préalable avec la caisse destinataire</li>
              <li className="mb-2"><strong>Régularisation</strong> : Confirmation électronique dès rétablissement du service</li>
            </ol>
          </div>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Organisation et responsabilités</h2>
          <p className="mb-4">
            Une équipe spécifique sera constituée pour gérer les procédures manuelles, avec des horaires étendus pendant 
            les périodes critiques de migration.
          </p>
          
          <div className="overflow-x-auto mb-6">
            <table className="min-w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 px-4 py-2">Rôle</th>
                  <th className="border border-gray-300 px-4 py-2">Responsabilités</th>
                  <th className="border border-gray-300 px-4 py-2">Disponibilité</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-gray-300 px-4 py-2">Coordinateur des procédures manuelles</td>
                  <td className="border border-gray-300 px-4 py-2">Supervision, décision d'activation, liaison avec la direction</td>
                  <td className="border border-gray-300 px-4 py-2">7j/7, 8h-20h</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2">Opérateurs RAFAM</td>
                  <td className="border border-gray-300 px-4 py-2">Traitement des annonces et vérifications RAFAM</td>
                  <td className="border border-gray-300 px-4 py-2">5j/7, 8h-18h</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 px-4 py-2">Opérateurs AVS</td>
                  <td className="border border-gray-300 px-4 py-2">Vérifications AVS et coordination avec la CdC</td>
                  <td className="border border-gray-300 px-4 py-2">5j/7, 8h-17h</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2">Gestionnaires de transferts</td>
                  <td className="border border-gray-300 px-4 py-2">Coordination des transferts entre caisses</td>
                  <td className="border border-gray-300 px-4 py-2">5j/7, 9h-16h</td>
                </tr>
              </tbody>
            </table>
          </div>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Formation, documentation et outils</h2>
          <p className="mb-4">
            Le plan prévoit une formation complète du personnel, une documentation détaillée et des outils spécifiques 
            pour faciliter la mise en œuvre des procédures manuelles.
          </p>
          
          <ul className="list-disc pl-6 mb-6">
            <li className="mb-2"><strong>Formation</strong> : Sessions de formation obligatoires pour tous les membres de l'équipe</li>
            <li className="mb-2"><strong>Documentation</strong> : Manuel complet des procédures manuelles avec exemples et cas pratiques</li>
            <li className="mb-2"><strong>Outils</strong> : Formulaires standardisés, registres de suivi, tableaux de bord de monitoring</li>
            <li className="mb-2"><strong>Tests</strong> : Exercices de simulation mensuels pour maintenir le niveau de préparation</li>
            <li className="mb-2"><strong>Retour d'expérience</strong> : Analyse systématique après chaque activation des procédures</li>
          </ul>
        </div>
        
        <div className="mt-12 flex justify-between">
          <Link href="/sections/plan-retour" className="text-blue-600 hover:underline">
            ← Plan de retour en arrière
          </Link>
          <Link href="/sections/periodes-critiques" className="text-blue-600 hover:underline">
            Identification des périodes critiques →
          </Link>
        </div>
      </div>
    </main>
  )
}
