import Link from 'next/link'
import Image from 'next/image'

export default function AnalyseContexte() {
  return (
    <main className="flex min-h-screen flex-col items-center p-8 md:p-24">
      <div className="max-w-5xl w-full">
        <nav className="mb-8">
          <Link href="/" className="text-blue-600 hover:underline">
            ← Retour à l'accueil
          </Link>
        </nav>
        
        <h1 className="text-3xl font-bold mb-8">Analyse du contexte</h1>
        
        <div className="prose max-w-none">
          <h2 className="text-2xl font-semibold mt-8 mb-4">Contexte général</h2>
          <p className="mb-4">
            Les caisses de compensation suisses sont responsables de la gestion de plusieurs prestations sociales, 
            dont les Allocations Familiales. La fusion envisagée concerne spécifiquement une caisse existante 
            (Agence 4) et la création potentielle d'une nouvelle structure centralisée.
          </p>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Problématique des SedexID</h2>
          <p className="mb-4">
            Sedex (Secure Data Exchange) est l'infrastructure d'échange sécurisé de données utilisée par les 
            institutions suisses de sécurité sociale. Chaque caisse de compensation possède un identifiant Sedex 
            unique (SedexID) qui lui permet d'échanger des données avec d'autres institutions, notamment avec le 
            Registre des Allocations Familiales (RAFAM).
          </p>
          
          <p className="mb-4">
            Dans le cadre d'une fusion, la gestion des SedexID pose plusieurs défis :
          </p>
          
          <ol className="list-decimal pl-6 mb-6">
            <li className="mb-2"><strong>Continuité des échanges de données</strong> : Assurer que les flux d'information ne sont pas interrompus pendant et après la fusion.</li>
            <li className="mb-2"><strong>Identification unique</strong> : Déterminer si la nouvelle entité fusionnée doit conserver un SedexID existant ou en créer un nouveau.</li>
            <li className="mb-2"><strong>Migration des affiliés</strong> : Gérer le transfert des affiliés d'une caisse à l'autre sans perturber les échanges avec le RAFAM.</li>
            <li className="mb-2"><strong>Coexistence temporaire</strong> : Gérer une période de transition où plusieurs SedexID pourraient coexister.</li>
          </ol>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Options de migration technique identifiées</h2>
          <p className="mb-4">
            Quatre options principales ont été identifiées pour la migration technique :
          </p>
          
          <h3 className="text-xl font-medium mt-6 mb-3">Option 1 : Conservation de l'ID SEDEX existant avec extension en Phase 3</h3>
          <ul className="list-disc pl-6 mb-4">
            <li><strong>Description</strong> : Conserver l'ID SEDEX de l'Agence 4 et étendre le périmètre d'affiliés uniquement en Phase 3.</li>
            <li><strong>Avantages</strong> : Simplicité technique, risques limités.</li>
            <li><strong>Inconvénients</strong> : Approche conservatrice qui retarde l'intégration complète des affiliés.</li>
          </ul>
          
          <h3 className="text-xl font-medium mt-6 mb-3">Option 2 : Utilisation du même ID SEDEX avec augmentation du périmètre dès la Phase 2</h3>
          <ul className="list-disc pl-6 mb-4">
            <li><strong>Description</strong> : Utiliser le même ID SEDEX que l'Agence 4, mais augmenter le périmètre d'affiliés dès la Phase 2 (caisse alpha).</li>
            <li><strong>Avantages</strong> : Intégration plus rapide des affiliés.</li>
            <li><strong>Inconvénients</strong> : Risques techniques liés à la configuration "deux caisses" sur le même SEDEX ID, notamment pour des raisons tarifaires ou de routage d'annonces.</li>
          </ul>
          
          <h3 className="text-xl font-medium mt-6 mb-3">Option 3 : Création d'un nouveau ID SEDEX</h3>
          <ul className="list-disc pl-6 mb-4">
            <li><strong>Description</strong> : Création d'une agence centrale avec un nouveau SEDEX ID, englobant toutes les fonctionnalités AF pour en faire une caisse ALFA, avec d'autres composantes métiers en Phase 3.</li>
            <li><strong>Avantages</strong> : 
              <ul className="list-disc pl-6 mt-2">
                <li>Séparation claire d'une "nouvelle caisse"</li>
                <li>Simplification des annonces pour le RAFAM</li>
                <li>Possibilité de migration incrémentale par lots dès la Phase 2</li>
              </ul>
            </li>
            <li><strong>Inconvénients</strong> : 
              <ul className="list-disc pl-6 mt-2">
                <li>Nécessité de s'assurer que toutes les annonces sont communiquées au RAFAM avant la migration incrémentale de l'affilié</li>
                <li>Complexité administrative initiale</li>
              </ul>
            </li>
          </ul>
          
          <h3 className="text-xl font-medium mt-6 mb-3">Option 4 : Mise en production différée en Phase 3</h3>
          <ul className="list-disc pl-6 mb-4">
            <li><strong>Description</strong> : N'envisager une mise en production qu'après stabilisation complète du produit.</li>
            <li><strong>Avantages</strong> : Système plus mature et éprouvé.</li>
            <li><strong>Inconvénients</strong> : Retarde la migration et peut s'avérer moins flexible si des évolutions légales surviennent entre-temps.</li>
          </ul>
          
          <div className="my-8">
            <h3 className="text-xl font-medium mb-4">Comparaison visuelle des options</h3>
            <div className="relative w-full h-80 md:h-96">
              <Image 
                src="/images/comparaison_options_migration.png" 
                alt="Comparaison des options de migration" 
                fill
                style={{objectFit: 'contain'}}
              />
            </div>
          </div>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Considérations spécifiques pour les Allocations Familiales</h2>
          <p className="mb-4">
            Les Allocations Familiales présentent des particularités qui influencent la stratégie de fusion :
          </p>
          
          <ol className="list-decimal pl-6 mb-6">
            <li className="mb-2"><strong>Cycle de traitement</strong> : Les AF suivent un cycle mensuel ou trimestriel de versement qui doit être respecté pendant la migration.</li>
            <li className="mb-2"><strong>Interactions avec le RAFAM</strong> : Les échanges avec le Registre des Allocations Familiales sont critiques et ne doivent pas être interrompus.</li>
            <li className="mb-2"><strong>Synchronisation avec d'autres systèmes</strong> : Les systèmes iPension et WebAVS sont en constante évolution (mises à jour légales ou correctives), ce qui complexifie la migration.</li>
          </ol>
        </div>
        
        <div className="mt-12 flex justify-between">
          <Link href="/sections/introduction" className="text-blue-600 hover:underline">
            ← Introduction
          </Link>
          <Link href="/sections/flux-donnees" className="text-blue-600 hover:underline">
            Documentation des flux de données →
          </Link>
        </div>
      </div>
    </main>
  )
}
