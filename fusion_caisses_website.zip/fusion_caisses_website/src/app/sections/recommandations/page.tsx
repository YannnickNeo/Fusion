import Link from 'next/link'
import Image from 'next/image'

export default function Recommandations() {
  return (
    <main className="flex min-h-screen flex-col items-center p-8 md:p-24">
      <div className="max-w-5xl w-full">
        <nav className="mb-8">
          <Link href="/" className="text-blue-600 hover:underline">
            ← Retour à l'accueil
          </Link>
        </nav>
        
        <h1 className="text-3xl font-bold mb-8">Recommandations finales</h1>
        
        <div className="prose max-w-none">
          <h2 className="text-2xl font-semibold mt-8 mb-4">Choix de l'option de migration</h2>
          <p className="mb-4">
            Sur la base de l'analyse complète, l'<strong>Option 3</strong> (création d'un nouveau SedexID) est recommandée pour les raisons suivantes :
          </p>
          
          <ol className="list-decimal pl-6 mb-6">
            <li className="mb-2">Elle permet une <strong>séparation claire</strong> entre l'ancienne et la nouvelle structure.</li>
            <li className="mb-2">Elle offre la possibilité d'une <strong>migration incrémentale</strong> dès la Phase 2.</li>
            <li className="mb-2">Elle <strong>simplifie les échanges avec le RAFAM</strong> en établissant une distinction nette.</li>
            <li className="mb-2">Elle permet de <strong>gérer en parallèle</strong> les deux structures pendant la transition.</li>
          </ol>
          
          <div className="my-8">
            <div className="relative w-full h-80 md:h-96">
              <Image 
                src="/images/comparaison_options_migration.png" 
                alt="Comparaison des options de migration" 
                fill
                style={{objectFit: 'contain'}}
              />
            </div>
            <p className="text-sm text-center text-gray-600 mt-2">
              Comparaison visuelle des options de migration montrant les avantages de l'Option 3
            </p>
          </div>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Calendrier recommandé</h2>
          <p className="mb-4">
            Le calendrier optimal pour la migration est le suivant :
          </p>
          
          <div className="overflow-x-auto mb-6">
            <table className="min-w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 px-4 py-2">Phase</th>
                  <th className="border border-gray-300 px-4 py-2">Étape</th>
                  <th className="border border-gray-300 px-4 py-2">Période recommandée</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-gray-300 px-4 py-2" rowSpan="4">Phase 1</td>
                  <td className="border border-gray-300 px-4 py-2">Configuration administrative</td>
                  <td className="border border-gray-300 px-4 py-2">Mars-Avril 2025</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2">Configuration technique</td>
                  <td className="border border-gray-300 px-4 py-2">Mai-Juin 2025</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 px-4 py-2">Tests d'intégration</td>
                  <td className="border border-gray-300 px-4 py-2">Juin-Juillet 2025</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2">Préparation migration</td>
                  <td className="border border-gray-300 px-4 py-2">Août-Septembre 2025</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 px-4 py-2" rowSpan="5">Phase 2</td>
                  <td className="border border-gray-300 px-4 py-2">Migration Lot 1 (10%)</td>
                  <td className="border border-gray-300 px-4 py-2">11-14 novembre 2025</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2">Évaluation et ajustements</td>
                  <td className="border border-gray-300 px-4 py-2">Décembre 2025</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 px-4 py-2">Migration Lot 2 (20%)</td>
                  <td className="border border-gray-300 px-4 py-2">11-14 mars 2026</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2">Migration Lot 3 (30%)</td>
                  <td className="border border-gray-300 px-4 py-2">11-14 avril 2026</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 px-4 py-2">Migration Lot 4 (40%)</td>
                  <td className="border border-gray-300 px-4 py-2">11-14 mai 2026</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2" rowSpan="4">Phase 3</td>
                  <td className="border border-gray-300 px-4 py-2">Vérification complète</td>
                  <td className="border border-gray-300 px-4 py-2">Juin 2026</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 px-4 py-2">Intégration autres prestations</td>
                  <td className="border border-gray-300 px-4 py-2">Juillet-Septembre 2026</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2">Désactivation ancien SedexID</td>
                  <td className="border border-gray-300 px-4 py-2">Octobre-Novembre 2026</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 px-4 py-2">Bilan et clôture</td>
                  <td className="border border-gray-300 px-4 py-2">Novembre-Décembre 2026</td>
                </tr>
              </tbody>
            </table>
          </div>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Mesures d'accompagnement essentielles</h2>
          <p className="mb-4">
            Pour garantir le succès de la migration, les mesures d'accompagnement suivantes sont recommandées :
          </p>
          
          <div className="bg-blue-50 p-6 rounded-lg mb-6">
            <ol className="list-decimal pl-6">
              <li className="mb-3">
                <strong>Coordination étroite avec le RAFAM</strong>
                <p className="text-sm mt-1">Établir un canal de communication privilégié et des points de contact dédiés.</p>
              </li>
              <li className="mb-3">
                <strong>Tests approfondis avant chaque lot de migration</strong>
                <p className="text-sm mt-1">Réaliser des tests de bout en bout pour chaque scénario d'échange.</p>
              </li>
              <li className="mb-3">
                <strong>Formation intensive du personnel</strong>
                <p className="text-sm mt-1">Former toutes les équipes concernées aux nouvelles procédures et aux procédures manuelles de secours.</p>
              </li>
              <li className="mb-3">
                <strong>Communication transparente avec les affiliés</strong>
                <p className="text-sm mt-1">Informer les affiliés des changements à venir et des impacts potentiels.</p>
              </li>
              <li className="mb-3">
                <strong>Surveillance renforcée pendant les périodes de migration</strong>
                <p className="text-sm mt-1">Mettre en place un monitoring en temps réel des échanges Sedex.</p>
              </li>
              <li className="mb-3">
                <strong>Équipe de support dédiée</strong>
                <p className="text-sm mt-1">Constituer une équipe spécifique pour traiter rapidement les incidents pendant la migration.</p>
              </li>
              <li className="mb-3">
                <strong>Documentation exhaustive</strong>
                <p className="text-sm mt-1">Maintenir une documentation à jour de toutes les procédures et configurations.</p>
              </li>
            </ol>
          </div>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Gouvernance du projet</h2>
          <p className="mb-4">
            Une structure de gouvernance claire est recommandée :
          </p>
          
          <ol className="list-decimal pl-6 mb-6">
            <li className="mb-2"><strong>Comité de pilotage</strong> : Direction de la caisse, responsables métiers, représentants IT</li>
            <li className="mb-2"><strong>Direction de projet</strong> : Responsable dédié avec autorité sur toutes les équipes impliquées</li>
            <li className="mb-2"><strong>Comité technique</strong> : Experts IT, Sedex et métier</li>
            <li className="mb-2"><strong>Équipe de coordination externe</strong> : Liaison avec RAFAM, CdC, OFAS</li>
          </ol>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Indicateurs de suivi</h2>
          <p className="mb-4">
            Les indicateurs suivants devraient être suivis tout au long du projet :
          </p>
          
          <div className="overflow-x-auto mb-6">
            <table className="min-w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 px-4 py-2">Indicateur</th>
                  <th className="border border-gray-300 px-4 py-2">Description</th>
                  <th className="border border-gray-300 px-4 py-2">Cible</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-gray-300 px-4 py-2">Taux de réussite des migrations</td>
                  <td className="border border-gray-300 px-4 py-2">Pourcentage de dossiers migrés sans anomalie</td>
                  <td className="border border-gray-300 px-4 py-2">&gt; 99.5%</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2">Continuité de service</td>
                  <td className="border border-gray-300 px-4 py-2">Pourcentage d'échanges Sedex traités avec succès</td>
                  <td className="border border-gray-300 px-4 py-2">&gt; 99.9%</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 px-4 py-2">Respect du calendrier</td>
                  <td className="border border-gray-300 px-4 py-2">Écart entre dates planifiées et réelles</td>
                  <td className="border border-gray-300 px-4 py-2">&lt; 2 semaines</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2">Satisfaction des utilisateurs</td>
                  <td className="border border-gray-300 px-4 py-2">Évaluation régulière</td>
                  <td className="border border-gray-300 px-4 py-2">&gt; 4/5</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 px-4 py-2">Impact sur les affiliés</td>
                  <td className="border border-gray-300 px-4 py-2">Nombre d'incidents ou réclamations</td>
                  <td className="border border-gray-300 px-4 py-2">&lt; 0.5%</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        
        <div className="mt-12 flex justify-between">
          <Link href="/sections/periodes-critiques" className="text-blue-600 hover:underline">
            ← Identification des périodes critiques
          </Link>
          <Link href="/sections/conclusion" className="text-blue-600 hover:underline">
            Conclusion →
          </Link>
        </div>
      </div>
    </main>
  )
}
