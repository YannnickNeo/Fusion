import Link from 'next/link'

export default function Introduction() {
  return (
    <main className="flex min-h-screen flex-col items-center p-8 md:p-24">
      <div className="max-w-5xl w-full">
        <nav className="mb-8">
          <Link href="/" className="text-blue-600 hover:underline">
            ← Retour à l'accueil
          </Link>
        </nav>
        
        <h1 className="text-3xl font-bold mb-8">Introduction</h1>
        
        <div className="prose max-w-none">
          <p className="mb-4">
            La fusion de caisses de compensation en Suisse représente un défi technique et organisationnel majeur, 
            particulièrement lorsqu'il s'agit de gérer les Allocations Familiales (AF). Ce rapport analyse en détail 
            les implications de cette fusion sur les échanges de données via l'infrastructure Sedex (Secure Data Exchange), 
            et propose des solutions concrètes pour assurer une transition fluide.
          </p>
          
          <p className="mb-4">
            Les caisses de compensation jouent un rôle central dans le système de sécurité sociale suisse, et toute 
            interruption de leurs services peut avoir des conséquences significatives pour les affiliés et les bénéficiaires. 
            La gestion des identifiants Sedex (SedexID) lors d'une fusion est particulièrement critique, car ces identifiants 
            sont utilisés pour authentifier et router tous les échanges électroniques avec les partenaires institutionnels.
          </p>
          
          <p className="mb-4">
            Ce rapport s'appuie sur l'analyse des options discutées lors de la réunion préparatoire et développe une 
            stratégie complète pour la migration, en tenant compte de tous les aspects techniques, organisationnels et métier.
          </p>
        </div>
        
        <div className="mt-12 flex justify-between">
          <Link href="/" className="text-blue-600 hover:underline">
            ← Accueil
          </Link>
          <Link href="/sections/analyse-contexte" className="text-blue-600 hover:underline">
            Analyse du contexte →
          </Link>
        </div>
      </div>
    </main>
  )
}
