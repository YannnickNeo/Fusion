import Link from 'next/link'

export default function PlanMigration() {
  return (
    <main className="flex min-h-screen flex-col items-center p-8 md:p-24">
      <div className="max-w-5xl w-full">
        <nav className="mb-8">
          <Link href="/" className="text-blue-600 hover:underline">
            ← Retour à l'accueil
          </Link>
        </nav>
        
        <h1 className="text-3xl font-bold mb-8">Plan de migration détaillé</h1>
        
        <div className="prose max-w-none">
          <h2 className="text-2xl font-semibold mt-8 mb-4">Vue d'ensemble de la migration</h2>
          <p className="mb-4">
            La migration sera organisée en trois phases principales :
          </p>
          
          <ul className="list-disc pl-6 mb-6">
            <li><strong>Phase 1 : Préparation</strong> - Configuration technique et administrative (T1-T2 2025)</li>
            <li><strong>Phase 2 : Migration incrémentale</strong> - Transfert progressif des affiliés (T3 2025 - T1 2026)</li>
            <li><strong>Phase 3 : Finalisation</strong> - Intégration complète et stabilisation (T2-T3 2026)</li>
          </ul>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Phase 1 : Préparation (T1-T2 2025)</h2>
          
          <h3 className="text-xl font-medium mt-6 mb-3">Jalon 1.1 : Configuration administrative (T1 2025, Semaines 1-6)</h3>
          <ul className="list-disc pl-6 mb-4">
            <li>Demande officielle d'un nouveau SedexID auprès de l'OFAS</li>
            <li>Préparation des documents administratifs</li>
            <li>Notification préliminaire aux partenaires</li>
          </ul>
          
          <h3 className="text-xl font-medium mt-6 mb-3">Jalon 1.2 : Configuration technique initiale (T1 2025, Semaines 7-12)</h3>
          <ul className="list-disc pl-6 mb-4">
            <li>Installation et configuration d'une nouvelle instance d'iPension/WebAVS</li>
            <li>Configuration du nouveau SedexID</li>
            <li>Tests de connectivité basiques</li>
          </ul>
          
          <h3 className="text-xl font-medium mt-6 mb-3">Jalon 1.3 : Tests d'intégration (T2 2025, Semaines 1-6)</h3>
          <ul className="list-disc pl-6 mb-4">
            <li>Tests d'intégration avec le RAFAM et la CdC</li>
            <li>Validation des formats d'échange et des routages</li>
          </ul>
          
          <h3 className="text-xl font-medium mt-6 mb-3">Jalon 1.4 : Préparation de la migration des données (T2 2025, Semaines 7-12)</h3>
          <ul className="list-disc pl-6 mb-4">
            <li>Développement des scripts et outils de migration</li>
            <li>Tests de migration sur un échantillon représentatif</li>
            <li>Finalisation du plan de migration incrémentale</li>
          </ul>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Phase 2 : Migration incrémentale (T3 2025 - T1 2026)</h2>
          
          <h3 className="text-xl font-medium mt-6 mb-3">Jalon 2.1 : Préparation du premier lot de migration (T3 2025, Semaines 1-4)</h3>
          <ul className="list-disc pl-6 mb-4">
            <li>Sélection du premier lot d'affiliés (10% du total)</li>
            <li>Communication ciblée aux affiliés concernés</li>
          </ul>
          
          <h3 className="text-xl font-medium mt-6 mb-3">Jalon 2.2 : Migration du premier lot (T3 2025, Semaines 5-8)</h3>
          <ul className="list-disc pl-6 mb-4">
            <li>Exécution de la migration des données</li>
            <li>Notification au RAFAM des changements d'affiliation</li>
            <li>Surveillance intensive des échanges Sedex</li>
          </ul>
          
          <h3 className="text-xl font-medium mt-6 mb-3">Jalons 2.3 à 2.6 : Migration des lots suivants</h3>
          <ul className="list-disc pl-6 mb-4">
            <li>Évaluation et ajustements après chaque lot</li>
            <li>Migration progressive des lots restants (20%, 30%, 40%)</li>
          </ul>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Phase 3 : Finalisation et stabilisation (T2-T3 2026)</h2>
          
          <h3 className="text-xl font-medium mt-6 mb-3">Jalon 3.1 : Vérification complète post-migration (T2 2026, Semaines 1-4)</h3>
          <ul className="list-disc pl-6 mb-4">
            <li>Audit complet des données migrées</li>
            <li>Vérification de la cohérence des échanges Sedex</li>
          </ul>
          
          <h3 className="text-xl font-medium mt-6 mb-3">Jalon 3.2 : Intégration des autres prestations (T2 2026, Semaines 5-12)</h3>
          <ul className="list-disc pl-6 mb-4">
            <li>Extension du périmètre fonctionnel à d'autres prestations</li>
          </ul>
          
          <h3 className="text-xl font-medium mt-6 mb-3">Jalon 3.3 : Désactivation de l'ancien SedexID (T3 2026, Semaines 1-6)</h3>
          <ul className="list-disc pl-6 mb-4">
            <li>Vérification préalable de l'absence d'échanges en cours</li>
            <li>Procédure de désactivation de l'ancien SedexID</li>
          </ul>
          
          <h3 className="text-xl font-medium mt-6 mb-3">Jalon 3.4 : Bilan et clôture du projet (T3 2026, Semaines 7-12)</h3>
          <ul className="list-disc pl-6 mb-4">
            <li>Évaluation complète du projet</li>
            <li>Clôture officielle du projet</li>
          </ul>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Matrice RACI et dépendances critiques</h2>
          <p className="mb-4">
            Le plan identifie clairement les responsabilités pour chaque jalon et les dépendances critiques qui doivent 
            être gérées avec attention, notamment l'obtention du nouveau SedexID et la coordination avec le RAFAM.
          </p>
          
          <div className="bg-blue-50 p-6 rounded-lg my-8">
            <h3 className="text-xl font-medium mb-4">Dépendances critiques</h3>
            <ol className="list-decimal pl-6">
              <li className="mb-2"><strong>Obtention du nouveau SedexID</strong> : Dépendance externe avec l'OFAS, conditionnant le démarrage de la configuration technique.</li>
              <li className="mb-2"><strong>Coordination avec le RAFAM</strong> : Dépendance externe majeure pour assurer la continuité des échanges pendant la migration.</li>
              <li className="mb-2"><strong>Disponibilité des ressources IT</strong> : Dépendance interne pour garantir la capacité d'exécution technique du projet.</li>
              <li className="mb-2"><strong>Cycles métier des Allocations Familiales</strong> : Dépendance métier influençant les fenêtres temporelles optimales pour la migration.</li>
              <li className="mb-2"><strong>Mises à jour d'iPension/WebAVS</strong> : Dépendance externe avec le fournisseur du logiciel pour assurer la compatibilité des versions.</li>
            </ol>
          </div>
        </div>
        
        <div className="mt-12 flex justify-between">
          <Link href="/sections/cartographie" className="text-blue-600 hover:underline">
            ← Cartographie des échanges de données
          </Link>
          <Link href="/sections/plan-retour" className="text-blue-600 hover:underline">
            Plan de retour en arrière →
          </Link>
        </div>
      </div>
    </main>
  )
}
