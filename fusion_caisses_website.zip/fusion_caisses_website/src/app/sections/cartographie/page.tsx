import Link from 'next/link'
import Image from 'next/image'

export default function Cartographie() {
  return (
    <main className="flex min-h-screen flex-col items-center p-8 md:p-24">
      <div className="max-w-5xl w-full">
        <nav className="mb-8">
          <Link href="/" className="text-blue-600 hover:underline">
            ← Retour à l'accueil
          </Link>
        </nav>
        
        <h1 className="text-3xl font-bold mb-8">Cartographie des échanges de données</h1>
        
        <div className="prose max-w-none">
          <h2 className="text-2xl font-semibold mt-8 mb-4">Entités principales</h2>
          <p className="mb-4">
            La cartographie identifie trois catégories d'entités :
          </p>
          
          <h3 className="text-xl font-medium mt-6 mb-3">1. Caisses</h3>
          <ul className="list-disc pl-6 mb-4">
            <li>Agence 4 (Caisse existante) : La caisse actuelle avec son SedexID établi</li>
            <li>Nouvelle Agence Centrale : La future caisse centralisée qui sera créée lors de la fusion</li>
          </ul>
          
          <h3 className="text-xl font-medium mt-6 mb-3">2. Systèmes</h3>
          <ul className="list-disc pl-6 mb-4">
            <li>iPension/WebAVS (Agence 4) : Le système informatique actuel de l'Agence 4</li>
            <li>iPension/WebAVS (Nouvelle Agence) : Le futur système de la Nouvelle Agence Centrale</li>
          </ul>
          
          <h3 className="text-xl font-medium mt-6 mb-3">3. Partenaires externes</h3>
          <ul className="list-disc pl-6 mb-4">
            <li>RAFAM (Registre des Allocations Familiales)</li>
            <li>CdC (UPI) : Centrale de Compensation</li>
            <li>OFAS : Office Fédéral des Assurances Sociales</li>
            <li>Autres Caisses : Autres caisses de compensation</li>
          </ul>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Flux de données existants et futurs</h2>
          
          <div className="my-8">
            <div className="relative w-full h-96 md:h-[500px]">
              <Image 
                src="/images/cartographie_flux_sedex.png" 
                alt="Cartographie des flux de données Sedex" 
                fill
                style={{objectFit: 'contain'}}
              />
            </div>
            <p className="text-sm text-center text-gray-600 mt-2">
              Cartographie des flux de données Sedex entre les différentes entités
            </p>
          </div>
          
          <p className="mb-4">
            La cartographie illustre les flux de données existants (lignes continues) et futurs (lignes pointillées) 
            entre les différentes entités. Elle met en évidence la duplication des flux pendant la période de transition, 
            où les deux agences (existante et nouvelle) devront gérer en parallèle les mêmes types d'échanges avec des 
            SedexID différents.
          </p>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Implications pour la gestion des SedexID</h2>
          <p className="mb-4">
            La cartographie met en évidence plusieurs implications importantes :
          </p>
          
          <ol className="list-decimal pl-6 mb-6">
            <li className="mb-2"><strong>Duplication des flux</strong> : Si les deux agences coexistent pendant une période de transition, les mêmes types de flux devront être gérés en parallèle.</li>
            <li className="mb-2"><strong>Redirection des messages</strong> : Les partenaires externes devront être informés des changements de SedexID.</li>
            <li className="mb-2"><strong>Continuité de service</strong> : La transition doit garantir qu'aucun message n'est perdu.</li>
            <li className="mb-2"><strong>Historique des échanges</strong> : L'accès à l'historique doit être maintenu, même si le SedexID change.</li>
          </ol>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Comparaison des options de migration</h2>
          
          <div className="my-8">
            <div className="relative w-full h-96 md:h-[500px]">
              <Image 
                src="/images/comparaison_options_migration.png" 
                alt="Comparaison des options de migration" 
                fill
                style={{objectFit: 'contain'}}
              />
            </div>
            <p className="text-sm text-center text-gray-600 mt-2">
              Comparaison visuelle des quatre options de migration
            </p>
          </div>
          
          <p className="mb-4">
            La comparaison visuelle des quatre options de migration met en évidence les avantages et inconvénients 
            de chaque approche. L'Option 3 (création d'un nouveau SedexID) apparaît comme la plus adaptée, offrant 
            un bon équilibre entre flexibilité de migration et clarté organisationnelle.
          </p>
        </div>
        
        <div className="mt-12 flex justify-between">
          <Link href="/sections/flux-donnees" className="text-blue-600 hover:underline">
            ← Documentation des flux de données
          </Link>
          <Link href="/sections/plan-migration" className="text-blue-600 hover:underline">
            Plan de migration détaillé →
          </Link>
        </div>
      </div>
    </main>
  )
}
