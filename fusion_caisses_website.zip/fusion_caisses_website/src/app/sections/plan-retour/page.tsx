import Link from 'next/link'

export default function PlanRetour() {
  return (
    <main className="flex min-h-screen flex-col items-center p-8 md:p-24">
      <div className="max-w-5xl w-full">
        <nav className="mb-8">
          <Link href="/" className="text-blue-600 hover:underline">
            ← Retour à l'accueil
          </Link>
        </nav>
        
        <h1 className="text-3xl font-bold mb-8">Plan de retour en arrière</h1>
        
        <div className="prose max-w-none">
          <h2 className="text-2xl font-semibold mt-8 mb-4">Principes généraux du plan de retour en arrière</h2>
          <p className="mb-4">
            Le plan de retour en arrière repose sur plusieurs principes fondamentaux :
          </p>
          
          <ol className="list-decimal pl-6 mb-6">
            <li className="mb-2"><strong>Préservation des données</strong> : Sauvegarde de toutes les données originales avant chaque opération</li>
            <li className="mb-2"><strong>Réversibilité des actions</strong> : Possibilité d'annuler chaque action jusqu'à un certain point</li>
            <li className="mb-2"><strong>Identification des points de non-retour</strong> : Identification claire des étapes irréversibles</li>
            <li className="mb-2"><strong>Procédures documentées</strong> : Documentation détaillée et tests préalables</li>
            <li className="mb-2"><strong>Responsabilités définies</strong> : Rôles et responsabilités clairement établis</li>
          </ol>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Identification des points de non-retour</h2>
          <p className="mb-4">
            Trois points de non-retour critiques sont identifiés :
          </p>
          
          <div className="bg-amber-50 p-6 rounded-lg my-6">
            <h3 className="text-xl font-medium mb-4">Points de non-retour</h3>
            <ol className="list-decimal pl-6">
              <li className="mb-3">
                <strong>Désactivation de l'ancien SedexID</strong> (Phase 3, Jalon 3.3)
                <p className="text-sm mt-1">Une fois l'ancien SedexID désactivé, il n'est plus possible de revenir à la configuration précédente sans une nouvelle demande administrative complète.</p>
              </li>
              <li className="mb-3">
                <strong>Migration du lot final</strong> (Phase 2, Jalon 2.6)
                <p className="text-sm mt-1">Après la migration du dernier lot d'affiliés, un retour en arrière complet devient extrêmement complexe et coûteux.</p>
              </li>
              <li className="mb-3">
                <strong>Notification officielle aux partenaires</strong> (Phase 1, Jalon 1.1)
                <p className="text-sm mt-1">Une fois les partenaires officiellement notifiés du changement de SedexID, un retour en arrière aurait un impact significatif sur la crédibilité de l'institution.</p>
              </li>
            </ol>
          </div>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Plan de retour en arrière par phase</h2>
          
          <h3 className="text-xl font-medium mt-6 mb-3">Phase 1 : Préparation</h3>
          <table className="min-w-full border-collapse border border-gray-300 mb-6">
            <thead>
              <tr className="bg-gray-100">
                <th className="border border-gray-300 px-4 py-2">Jalon</th>
                <th className="border border-gray-300 px-4 py-2">Sauvegardes préalables</th>
                <th className="border border-gray-300 px-4 py-2">Procédure de retour</th>
                <th className="border border-gray-300 px-4 py-2">Délai maximum</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="border border-gray-300 px-4 py-2">1.1 Configuration administrative</td>
                <td className="border border-gray-300 px-4 py-2">Documents administratifs</td>
                <td className="border border-gray-300 px-4 py-2">Retrait de la demande de SedexID</td>
                <td className="border border-gray-300 px-4 py-2">Avant notification officielle</td>
              </tr>
              <tr className="bg-gray-50">
                <td className="border border-gray-300 px-4 py-2">1.2 Configuration technique</td>
                <td className="border border-gray-300 px-4 py-2">Configuration initiale</td>
                <td className="border border-gray-300 px-4 py-2">Restauration de la configuration</td>
                <td className="border border-gray-300 px-4 py-2">1 mois</td>
              </tr>
              <tr>
                <td className="border border-gray-300 px-4 py-2">1.3 Tests d'intégration</td>
                <td className="border border-gray-300 px-4 py-2">Environnement de test</td>
                <td className="border border-gray-300 px-4 py-2">Restauration de l'environnement</td>
                <td className="border border-gray-300 px-4 py-2">2 semaines</td>
              </tr>
              <tr className="bg-gray-50">
                <td className="border border-gray-300 px-4 py-2">1.4 Préparation migration</td>
                <td className="border border-gray-300 px-4 py-2">Scripts et outils</td>
                <td className="border border-gray-300 px-4 py-2">Révision des scripts</td>
                <td className="border border-gray-300 px-4 py-2">1 mois</td>
              </tr>
            </tbody>
          </table>
          
          <h3 className="text-xl font-medium mt-6 mb-3">Phase 2 : Migration incrémentale</h3>
          <table className="min-w-full border-collapse border border-gray-300 mb-6">
            <thead>
              <tr className="bg-gray-100">
                <th className="border border-gray-300 px-4 py-2">Jalon</th>
                <th className="border border-gray-300 px-4 py-2">Sauvegardes préalables</th>
                <th className="border border-gray-300 px-4 py-2">Procédure de retour</th>
                <th className="border border-gray-300 px-4 py-2">Délai maximum</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="border border-gray-300 px-4 py-2">2.1 Préparation premier lot</td>
                <td className="border border-gray-300 px-4 py-2">Liste des affiliés</td>
                <td className="border border-gray-300 px-4 py-2">Révision de la sélection</td>
                <td className="border border-gray-300 px-4 py-2">2 semaines</td>
              </tr>
              <tr className="bg-gray-50">
                <td className="border border-gray-300 px-4 py-2">2.2 Migration premier lot</td>
                <td className="border border-gray-300 px-4 py-2">Données complètes</td>
                <td className="border border-gray-300 px-4 py-2">Restauration des données</td>
                <td className="border border-gray-300 px-4 py-2">72 heures</td>
              </tr>
              <tr>
                <td className="border border-gray-300 px-4 py-2">2.3-2.5 Lots suivants</td>
                <td className="border border-gray-300 px-4 py-2">Données complètes</td>
                <td className="border border-gray-300 px-4 py-2">Restauration des données</td>
                <td className="border border-gray-300 px-4 py-2">72 heures</td>
              </tr>
              <tr className="bg-gray-50">
                <td className="border border-gray-300 px-4 py-2">2.6 Lot final</td>
                <td className="border border-gray-300 px-4 py-2">Données complètes</td>
                <td className="border border-gray-300 px-4 py-2">Restauration complexe</td>
                <td className="border border-gray-300 px-4 py-2">48 heures</td>
              </tr>
            </tbody>
          </table>
          
          <h3 className="text-xl font-medium mt-6 mb-3">Phase 3 : Finalisation</h3>
          <table className="min-w-full border-collapse border border-gray-300 mb-6">
            <thead>
              <tr className="bg-gray-100">
                <th className="border border-gray-300 px-4 py-2">Jalon</th>
                <th className="border border-gray-300 px-4 py-2">Sauvegardes préalables</th>
                <th className="border border-gray-300 px-4 py-2">Procédure de retour</th>
                <th className="border border-gray-300 px-4 py-2">Délai maximum</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="border border-gray-300 px-4 py-2">3.1 Vérification post-migration</td>
                <td className="border border-gray-300 px-4 py-2">Rapports d'audit</td>
                <td className="border border-gray-300 px-4 py-2">Correction des anomalies</td>
                <td className="border border-gray-300 px-4 py-2">1 mois</td>
              </tr>
              <tr className="bg-gray-50">
                <td className="border border-gray-300 px-4 py-2">3.2 Intégration autres prestations</td>
                <td className="border border-gray-300 px-4 py-2">Configuration initiale</td>
                <td className="border border-gray-300 px-4 py-2">Restauration configuration</td>
                <td className="border border-gray-300 px-4 py-2">2 semaines</td>
              </tr>
              <tr>
                <td className="border border-gray-300 px-4 py-2">3.3 Désactivation ancien SedexID</td>
                <td className="border border-gray-300 px-4 py-2">Documentation complète</td>
                <td className="border border-gray-300 px-4 py-2">Non réversible</td>
                <td className="border border-gray-300 px-4 py-2">N/A</td>
              </tr>
            </tbody>
          </table>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Critères de déclenchement du retour en arrière</h2>
          <p className="mb-4">
            Des critères précis sont définis pour déclencher un retour en arrière, tant sur le plan technique 
            (perte de données, dysfonctionnement des échanges) que métier (impact sur les versements, non-conformité réglementaire).
          </p>
          
          <div className="bg-red-50 p-6 rounded-lg my-6">
            <h3 className="text-xl font-medium mb-4">Critères de déclenchement</h3>
            <h4 className="text-lg font-medium mt-4 mb-2">Critères techniques</h4>
            <ul className="list-disc pl-6 mb-4">
              <li>Perte de données supérieure à 0.1% lors de la migration</li>
              <li>Taux d'échec des échanges Sedex supérieur à 5% pendant plus de 24 heures</li>
              <li>Indisponibilité du système pendant plus de 4 heures consécutives</li>
              <li>Corruption des données affectant plus de 1% des dossiers</li>
            </ul>
            
            <h4 className="text-lg font-medium mt-4 mb-2">Critères métier</h4>
            <ul className="list-disc pl-6">
              <li>Retard de versement des allocations supérieur à 48 heures</li>
              <li>Non-conformité réglementaire avérée</li>
              <li>Impact sur plus de 5% des bénéficiaires</li>
              <li>Décision formelle de la direction suite à une évaluation des risques</li>
            </ul>
          </div>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Procédure de décision et tests</h2>
          <p className="mb-4">
            Le plan établit une procédure claire pour la prise de décision et prévoit des tests réguliers pour 
            garantir l'efficacité des procédures de retour en arrière.
          </p>
          
          <ol className="list-decimal pl-6 mb-6">
            <li className="mb-2"><strong>Détection</strong> : Surveillance continue des indicateurs clés</li>
            <li className="mb-2"><strong>Évaluation</strong> : Analyse rapide par l'équipe technique (max 2 heures)</li>
            <li className="mb-2"><strong>Escalade</strong> : Notification au comité de crise si les seuils sont dépassés</li>
            <li className="mb-2"><strong>Décision</strong> : Prise de décision par le comité de crise (max 1 heure)</li>
            <li className="mb-2"><strong>Exécution</strong> : Mise en œuvre du plan de retour par l'équipe dédiée</li>
            <li className="mb-2"><strong>Vérification</strong> : Contrôle post-retour pour confirmer la restauration</li>
            <li className="mb-2"><strong>Communication</strong> : Information aux parties prenantes</li>
          </ol>
        </div>
        
        <div className="mt-12 flex justify-between">
          <Link href="/sections/plan-migration" className="text-blue-600 hover:underline">
            ← Plan de migration détaillé
          </Link>
          <Link href="/sections/procedures-manuelles" className="text-blue-600 hover:underline">
            Procédures manuelles temporaires →
          </Link>
        </div>
      </div>
    </main>
  )
}
