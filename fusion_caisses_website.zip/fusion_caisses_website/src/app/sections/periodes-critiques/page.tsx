import Link from 'next/link'

export default function PeriodesCritiques() {
  return (
    <main className="flex min-h-screen flex-col items-center p-8 md:p-24">
      <div className="max-w-5xl w-full">
        <nav className="mb-8">
          <Link href="/" className="text-blue-600 hover:underline">
            ← Retour à l'accueil
          </Link>
        </nav>
        
        <h1 className="text-3xl font-bold mb-8">Identification des périodes critiques</h1>
        
        <div className="prose max-w-none">
          <h2 className="text-2xl font-semibold mt-8 mb-4">Analyse des cycles métier des Allocations Familiales</h2>
          <p className="mb-4">
            Les Allocations Familiales suivent plusieurs cycles métier qui influencent le choix des périodes de migration :
          </p>
          
          <ol className="list-decimal pl-6 mb-6">
            <li className="mb-2">
              <strong>Cycle mensuel de versement</strong> : 
              <ul className="list-disc pl-6 mt-1">
                <li>Préparation (15-20 du mois)</li>
                <li>Génération des ordres (20-25 du mois)</li>
                <li>Transmission (25-27 du mois)</li>
                <li>Versement (1-5 du mois suivant)</li>
                <li>Traitement des anomalies (5-10 du mois suivant)</li>
              </ul>
            </li>
            <li className="mb-2">
              <strong>Cycle annuel des adaptations légales</strong> : 
              <ul className="list-disc pl-6 mt-1">
                <li>Annonce (septembre-octobre)</li>
                <li>Paramétrage (novembre-décembre)</li>
                <li>Entrée en vigueur (1er janvier)</li>
                <li>Régularisations (janvier-février)</li>
              </ul>
            </li>
            <li className="mb-2">
              <strong>Cycle fiscal et statistique</strong> : 
              <ul className="list-disc pl-6 mt-1">
                <li>Certificats annuels (janvier)</li>
                <li>Statistiques trimestrielles</li>
                <li>Rapport annuel (31 mars)</li>
              </ul>
            </li>
            <li className="mb-2">
              <strong>Cycle des contrôles d'employeurs</strong> : 
              <ul className="list-disc pl-6 mt-1">
                <li>Planification (janvier)</li>
                <li>Exécution (février-novembre)</li>
                <li>Finalisation (novembre-décembre)</li>
              </ul>
            </li>
          </ol>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Événements spécifiques à forte charge</h2>
          <p className="mb-4">
            Plusieurs événements génèrent une charge exceptionnelle :
          </p>
          
          <ul className="list-disc pl-6 mb-6">
            <li className="mb-2"><strong>Rentrée scolaire</strong> : Mi-août à mi-octobre</li>
            <li className="mb-2"><strong>Fin d'apprentissage/études</strong> : Mi-mai à fin juillet</li>
            <li className="mb-2"><strong>Indexations des allocations</strong> : Variable selon les cantons</li>
          </ul>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Périodes critiques pour les échanges Sedex</h2>
          <p className="mb-4">
            L'analyse révèle des périodes de forte intensité d'échanges :
          </p>
          
          <div className="overflow-x-auto mb-6">
            <table className="min-w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 px-4 py-2">Type d'échange</th>
                  <th className="border border-gray-300 px-4 py-2">Périodes de forte intensité</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-gray-300 px-4 py-2">Échanges RAFAM</td>
                  <td className="border border-gray-300 px-4 py-2">Août-Octobre et Janvier</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2">Échanges CdC</td>
                  <td className="border border-gray-300 px-4 py-2">Septembre-Octobre et Janvier-Février</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 px-4 py-2">Échanges OFAS</td>
                  <td className="border border-gray-300 px-4 py-2">Janvier-Mars et premières semaines de chaque trimestre</td>
                </tr>
              </tbody>
            </table>
          </div>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Synthèse des périodes à éviter</h2>
          
          <h3 className="text-xl font-medium mt-6 mb-3">Périodes à éviter absolument</h3>
          <div className="bg-red-50 p-6 rounded-lg mb-6">
            <ol className="list-decimal pl-6">
              <li className="mb-2"><strong>Décembre à mi-février</strong> : Adaptations légales, clôture d'année</li>
              <li className="mb-2"><strong>20 du mois au 10 du mois suivant</strong> : Cycle de versement mensuel</li>
              <li className="mb-2"><strong>Mi-août à mi-octobre</strong> : Rentrée scolaire</li>
              <li className="mb-2"><strong>Mi-mai à fin juillet</strong> : Fin d'études/apprentissage</li>
            </ol>
          </div>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Fenêtres optimales pour la migration</h2>
          <p className="mb-4">
            Le plan identifie les fenêtres optimales pour chaque phase et lot de migration, recommandant notamment :
          </p>
          
          <div className="bg-green-50 p-6 rounded-lg mb-6">
            <ul className="list-disc pl-6">
              <li className="mb-2"><strong>Phase 1</strong> : Mars-Avril 2025</li>
              <li className="mb-2"><strong>Migrations de lots</strong> : Entre le 11 et le 14 de chaque mois (période la plus calme)</li>
              <li className="mb-2"><strong>Finalisation</strong> : Avant décembre 2026</li>
            </ul>
          </div>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Calendrier de migration recommandé</h2>
          <p className="mb-4">
            Un calendrier optimal est proposé, tenant compte de toutes les contraintes identifiées et maximisant les chances de succès de la migration.
          </p>
          
          <div className="overflow-x-auto mb-6">
            <table className="min-w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 px-4 py-2">Phase</th>
                  <th className="border border-gray-300 px-4 py-2">Étape</th>
                  <th className="border border-gray-300 px-4 py-2">Période recommandée</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-gray-300 px-4 py-2" rowSpan="4">Phase 1</td>
                  <td className="border border-gray-300 px-4 py-2">Configuration administrative</td>
                  <td className="border border-gray-300 px-4 py-2">Mars-Avril 2025</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2">Configuration technique</td>
                  <td className="border border-gray-300 px-4 py-2">Mai-Juin 2025</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 px-4 py-2">Tests d'intégration</td>
                  <td className="border border-gray-300 px-4 py-2">Juin-Juillet 2025</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2">Préparation migration</td>
                  <td className="border border-gray-300 px-4 py-2">Août-Septembre 2025</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 px-4 py-2" rowSpan="5">Phase 2</td>
                  <td className="border border-gray-300 px-4 py-2">Migration Lot 1 (10%)</td>
                  <td className="border border-gray-300 px-4 py-2">11-14 novembre 2025</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2">Évaluation et ajustements</td>
                  <td className="border border-gray-300 px-4 py-2">Décembre 2025</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 px-4 py-2">Migration Lot 2 (20%)</td>
                  <td className="border border-gray-300 px-4 py-2">11-14 mars 2026</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2">Migration Lot 3 (30%)</td>
                  <td className="border border-gray-300 px-4 py-2">11-14 avril 2026</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 px-4 py-2">Migration Lot 4 (40%)</td>
                  <td className="border border-gray-300 px-4 py-2">11-14 mai 2026</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2" rowSpan="4">Phase 3</td>
                  <td className="border border-gray-300 px-4 py-2">Vérification complète</td>
                  <td className="border border-gray-300 px-4 py-2">Juin 2026</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 px-4 py-2">Intégration autres prestations</td>
                  <td className="border border-gray-300 px-4 py-2">Juillet-Septembre 2026</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="border border-gray-300 px-4 py-2">Désactivation ancien SedexID</td>
                  <td className="border border-gray-300 px-4 py-2">Octobre-Novembre 2026</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 px-4 py-2">Bilan et clôture</td>
                  <td className="border border-gray-300 px-4 py-2">Novembre-Décembre 2026</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        
        <div className="mt-12 flex justify-between">
          <Link href="/sections/procedures-manuelles" className="text-blue-600 hover:underline">
            ← Procédures manuelles temporaires
          </Link>
          <Link href="/sections/recommandations" className="text-blue-600 hover:underline">
            Recommandations finales →
          </Link>
        </div>
      </div>
    </main>
  )
}
