import Image from 'next/image'
import Link from 'next/link'

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center p-8 md:p-24">
      <div className="max-w-5xl w-full">
        <h1 className="text-4xl font-bold text-center mb-8">
          Rapport d&apos;expert sur la fusion des caisses de compensation en Suisse
        </h1>
        <h2 className="text-2xl font-semibold text-center mb-12">
          Gestion des SedexID pour les Allocations Familiales
        </h2>

        <div className="bg-blue-50 p-6 rounded-lg mb-12">
          <h3 className="text-xl font-semibold mb-4">Résumé exécutif</h3>
          <p className="mb-4">
            Ce rapport présente une analyse complète et des recommandations détaillées pour la fusion de caisses de compensation en Suisse, 
            avec un focus particulier sur la problématique des identifiants Sedex (SedexID) dans le contexte des Allocations Familiales.
          </p>
          <p className="mb-4">
            L&apos;analyse révèle que l&apos;<strong>Option 3</strong> (création d&apos;un nouveau SedexID pour une agence centrale) représente 
            la solution optimale, permettant une migration incrémentale des affiliés tout en maintenant une séparation claire entre les 
            structures existantes et nouvelles. Cette approche offre la flexibilité nécessaire pour gérer la transition par phases, 
            tout en minimisant les risques d&apos;interruption des services.
          </p>
          <p className="mb-4">
            Le rapport propose un plan de migration détaillé en trois phases, s&apos;étendant de mars 2025 à décembre 2026, avec des jalons 
            précis et des fenêtres temporelles optimales tenant compte des cycles métier des Allocations Familiales. Des procédures 
            manuelles temporaires et un plan de retour en arrière complet sont également définis pour garantir la continuité des 
            services en toutes circonstances.
          </p>
          <p>
            La mise en œuvre de ces recommandations permettra une fusion réussie des caisses de compensation, avec un impact minimal 
            sur les affiliés et les bénéficiaires des allocations familiales.
          </p>
        </div>

        <div className="mb-12">
          <h3 className="text-xl font-semibold mb-6">Visualisations clés</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="border rounded-lg p-4 flex flex-col items-center">
              <h4 className="text-lg font-medium mb-3">Cartographie des flux de données Sedex</h4>
              <div className="relative w-full h-64 md:h-80">
                <Image 
                  src="/images/cartographie_flux_sedex.png" 
                  alt="Cartographie des flux de données Sedex" 
                  fill
                  style={{objectFit: 'contain'}}
                />
              </div>
            </div>
            <div className="border rounded-lg p-4 flex flex-col items-center">
              <h4 className="text-lg font-medium mb-3">Comparaison des options de migration</h4>
              <div className="relative w-full h-64 md:h-80">
                <Image 
                  src="/images/comparaison_options_migration.png" 
                  alt="Comparaison des options de migration" 
                  fill
                  style={{objectFit: 'contain'}}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="mb-12">
          <h3 className="text-xl font-semibold mb-6">Table des matières</h3>
          <nav className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Link href="/sections/introduction" className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
              1. Introduction
            </Link>
            <Link href="/sections/analyse-contexte" className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
              2. Analyse du contexte
            </Link>
            <Link href="/sections/flux-donnees" className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
              3. Documentation des flux de données Sedex
            </Link>
            <Link href="/sections/cartographie" className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
              4. Cartographie des échanges de données
            </Link>
            <Link href="/sections/plan-migration" className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
              5. Plan de migration détaillé
            </Link>
            <Link href="/sections/plan-retour" className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
              6. Plan de retour en arrière
            </Link>
            <Link href="/sections/procedures-manuelles" className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
              7. Procédures manuelles temporaires
            </Link>
            <Link href="/sections/periodes-critiques" className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
              8. Identification des périodes critiques
            </Link>
            <Link href="/sections/recommandations" className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
              9. Recommandations finales
            </Link>
            <Link href="/sections/conclusion" className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
              10. Conclusion
            </Link>
            <Link href="/sections/annexes" className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
              11. Annexes
            </Link>
          </nav>
        </div>
      </div>
    </main>
  )
}
