import Link from 'next/link'

export default function Layout({ children }) {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-blue-800 text-white py-4">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <Link href="/" className="text-xl font-bold mb-4 md:mb-0">
              Fusion des Caisses de Compensation en Suisse
            </Link>
            <nav className="flex flex-wrap justify-center gap-4">
              <Link href="/sections/introduction" className="hover:underline">
                Introduction
              </Link>
              <Link href="/sections/analyse-contexte" className="hover:underline">
                Analyse
              </Link>
              <Link href="/sections/flux-donnees" className="hover:underline">
                Flux Sedex
              </Link>
              <Link href="/sections/plan-migration" className="hover:underline">
                Migration
              </Link>
              <Link href="/sections/recommandations" className="hover:underline">
                Recommandations
              </Link>
            </nav>
          </div>
        </div>
      </header>
      
      <main className="flex-grow">
        {children}
      </main>
      
      <footer className="bg-gray-100 py-6">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <p className="text-gray-600">Rapport d'expert sur la fusion des caisses de compensation en Suisse</p>
              <p className="text-gray-500 text-sm">Gestion des SedexID pour les Allocations Familiales</p>
            </div>
            <div className="text-gray-500 text-sm">
              © 2025 - Tous droits réservés
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
