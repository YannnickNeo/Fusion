# Rapport d'expert sur la fusion des caisses de compensation en Suisse
# Gestion des SedexID pour les Allocations Familiales

## Résumé exécutif

Ce rapport présente une analyse complète et des recommandations détaillées pour la fusion de caisses de compensation en Suisse, avec un focus particulier sur la problématique des identifiants Sedex (SedexID) dans le contexte des Allocations Familiales. 

L'analyse révèle que l'**Option 3** (création d'un nouveau SedexID pour une agence centrale) représente la solution optimale, permettant une migration incrémentale des affiliés tout en maintenant une séparation claire entre les structures existantes et nouvelles. Cette approche offre la flexibilité nécessaire pour gérer la transition par phases, tout en minimisant les risques d'interruption des services.

Le rapport propose un plan de migration détaillé en trois phases, s'étendant de mars 2025 à décembre 2026, avec des jalons précis et des fenêtres temporelles optimales tenant compte des cycles métier des Allocations Familiales. Des procédures manuelles temporaires et un plan de retour en arrière complet sont également définis pour garantir la continuité des services en toutes circonstances.

La mise en œuvre de ces recommandations permettra une fusion réussie des caisses de compensation, avec un impact minimal sur les affiliés et les bénéficiaires des allocations familiales.

## Table des matières

1. [Introduction](#introduction)
2. [Analyse du contexte](#analyse-du-contexte)
3. [Documentation des flux de données Sedex existants](#documentation-des-flux-de-données-sedex-existants)
4. [Cartographie des échanges de données](#cartographie-des-échanges-de-données)
5. [Plan de migration détaillé](#plan-de-migration-détaillé)
6. [Plan de retour en arrière](#plan-de-retour-en-arrière)
7. [Procédures manuelles temporaires](#procédures-manuelles-temporaires)
8. [Identification des périodes critiques](#identification-des-périodes-critiques)
9. [Recommandations finales](#recommandations-finales)
10. [Conclusion](#conclusion)
11. [Annexes](#annexes)

## Introduction

La fusion de caisses de compensation en Suisse représente un défi technique et organisationnel majeur, particulièrement lorsqu'il s'agit de gérer les Allocations Familiales (AF). Ce rapport analyse en détail les implications de cette fusion sur les échanges de données via l'infrastructure Sedex (Secure Data Exchange), et propose des solutions concrètes pour assurer une transition fluide.

Les caisses de compensation jouent un rôle central dans le système de sécurité sociale suisse, et toute interruption de leurs services peut avoir des conséquences significatives pour les affiliés et les bénéficiaires. La gestion des identifiants Sedex (SedexID) lors d'une fusion est particulièrement critique, car ces identifiants sont utilisés pour authentifier et router tous les échanges électroniques avec les partenaires institutionnels.

Ce rapport s'appuie sur l'analyse des options discutées lors de la réunion préparatoire et développe une stratégie complète pour la migration, en tenant compte de tous les aspects techniques, organisationnels et métier.

## Analyse du contexte

### Contexte général

Les caisses de compensation suisses sont responsables de la gestion de plusieurs prestations sociales, dont les Allocations Familiales. La fusion envisagée concerne spécifiquement une caisse existante (Agence 4) et la création potentielle d'une nouvelle structure centralisée.

### Problématique des SedexID

Sedex (Secure Data Exchange) est l'infrastructure d'échange sécurisé de données utilisée par les institutions suisses de sécurité sociale. Chaque caisse de compensation possède un identifiant Sedex unique (SedexID) qui lui permet d'échanger des données avec d'autres institutions, notamment avec le Registre des Allocations Familiales (RAFAM).

Dans le cadre d'une fusion, la gestion des SedexID pose plusieurs défis :

1. **Continuité des échanges de données** : Assurer que les flux d'information ne sont pas interrompus pendant et après la fusion.
2. **Identification unique** : Déterminer si la nouvelle entité fusionnée doit conserver un SedexID existant ou en créer un nouveau.
3. **Migration des affiliés** : Gérer le transfert des affiliés d'une caisse à l'autre sans perturber les échanges avec le RAFAM.
4. **Coexistence temporaire** : Gérer une période de transition où plusieurs SedexID pourraient coexister.

### Options de migration technique identifiées

Quatre options principales ont été identifiées pour la migration technique :

#### Option 1 : Conservation de l'ID SEDEX existant avec extension en Phase 3
- **Description** : Conserver l'ID SEDEX de l'Agence 4 et étendre le périmètre d'affiliés uniquement en Phase 3.
- **Avantages** : Simplicité technique, risques limités.
- **Inconvénients** : Approche conservatrice qui retarde l'intégration complète des affiliés.

#### Option 2 : Utilisation du même ID SEDEX avec augmentation du périmètre dès la Phase 2
- **Description** : Utiliser le même ID SEDEX que l'Agence 4, mais augmenter le périmètre d'affiliés dès la Phase 2 (caisse alpha).
- **Avantages** : Intégration plus rapide des affiliés.
- **Inconvénients** : Risques techniques liés à la configuration "deux caisses" sur le même SEDEX ID, notamment pour des raisons tarifaires ou de routage d'annonces.

#### Option 3 : Création d'un nouveau ID SEDEX
- **Description** : Création d'une agence centrale avec un nouveau SEDEX ID, englobant toutes les fonctionnalités AF pour en faire une caisse ALFA, avec d'autres composantes métiers en Phase 3.
- **Avantages** : 
  - Séparation claire d'une "nouvelle caisse"
  - Simplification des annonces pour le RAFAM
  - Possibilité de migration incrémentale par lots dès la Phase 2
- **Inconvénients** : 
  - Nécessité de s'assurer que toutes les annonces sont communiquées au RAFAM avant la migration incrémentale de l'affilié
  - Complexité administrative initiale

#### Option 4 : Mise en production différée en Phase 3
- **Description** : N'envisager une mise en production qu'après stabilisation complète du produit.
- **Avantages** : Système plus mature et éprouvé.
- **Inconvénients** : Retarde la migration et peut s'avérer moins flexible si des évolutions légales surviennent entre-temps.

### Considérations spécifiques pour les Allocations Familiales

Les Allocations Familiales présentent des particularités qui influencent la stratégie de fusion :

1. **Cycle de traitement** : Les AF suivent un cycle mensuel ou trimestriel de versement qui doit être respecté pendant la migration.
2. **Interactions avec le RAFAM** : Les échanges avec le Registre des Allocations Familiales sont critiques et ne doivent pas être interrompus.
3. **Synchronisation avec d'autres systèmes** : Les systèmes iPension et WebAVS sont en constante évolution (mises à jour légales ou correctives), ce qui complexifie la migration.

## Documentation des flux de données Sedex existants

### Qu'est-ce que Sedex?

Sedex (Secure Data Exchange) est l'infrastructure nationale suisse d'échange sécurisé de données entre les institutions de sécurité sociale. Chaque institution participant à ce réseau possède un identifiant unique (SedexID) qui permet d'authentifier et de router correctement les messages échangés.

### Flux de données principaux utilisant les identifiants Sedex

#### 1. Échanges avec le Registre des Allocations Familiales (RAFAM)

Ces échanges comprennent :
- Annonces de nouvelles allocations (Caisse → RAFAM)
- Modifications d'allocations existantes (Caisse → RAFAM)
- Fin d'allocations (Caisse → RAFAM)
- Vérifications de droit (RAFAM → Caisse)
- Réponses aux vérifications (Caisse → RAFAM)

Les messages sont structurés en XML selon le schéma eCH-0058, et contiennent systématiquement le SedexID de l'émetteur, permettant au RAFAM d'identifier la caisse d'origine.

#### 2. Échanges avec la Centrale de Compensation (CdC)

Ces échanges comprennent :
- Vérification des numéros AVS (Caisse → CdC)
- Réponses aux vérifications AVS (CdC → Caisse)

Les messages suivent le format eCH-0085 et sont essentiels pour valider l'identité des allocataires et des enfants.

#### 3. Échanges avec l'Office Fédéral des Assurances Sociales (OFAS)

Ces échanges comprennent principalement les rapports statistiques trimestriels ou annuels sur les allocations familiales.

#### 4. Échanges entre caisses de compensation

Ces échanges concernent principalement les transferts de dossiers lors d'un changement d'affiliation.

### Fréquence et volume des échanges

| Type d'échange | Fréquence | Volume estimé (caisse moyenne) |
|----------------|-----------|-------------------------------|
| Nouvelles allocations | Temps réel | 50-100 par jour |
| Modifications | Temps réel | 20-50 par jour |
| Fins d'allocations | Temps réel | 10-30 par jour |
| Vérifications de droit | Temps réel | 30-80 par jour |
| Vérifications AVS | Temps réel/batch | 50-200 par jour |
| Rapports statistiques | Trimestriel/Annuel | 1-4 par an |
| Transferts de dossiers | À la demande | 5-20 par mois |

### Implications pour la fusion des caisses

La documentation des flux de données Sedex existants révèle plusieurs points critiques à considérer lors de la fusion des caisses :

1. **Identification unique** : Chaque message Sedex contient le SedexID de l'émetteur, ce qui permet au destinataire d'identifier la caisse d'origine.
2. **Routage des messages** : Le RAFAM et les autres partenaires utilisent le SedexID pour router les messages vers la bonne caisse.
3. **Historique des échanges** : Les messages précédemment échangés font référence à l'ancien SedexID.
4. **Continuité de service** : Les échanges en temps réel ne doivent pas être interrompus pendant la migration.
5. **Synchronisation des systèmes** : Les systèmes iPension/WebAVS doivent être configurés pour utiliser le bon SedexID.

## Cartographie des échanges de données

### Entités principales

La cartographie identifie trois catégories d'entités :

1. **Caisses** :
   - Agence 4 (Caisse existante) : La caisse actuelle avec son SedexID établi
   - Nouvelle Agence Centrale : La future caisse centralisée qui sera créée lors de la fusion

2. **Systèmes** :
   - iPension/WebAVS (Agence 4) : Le système informatique actuel de l'Agence 4
   - iPension/WebAVS (Nouvelle Agence) : Le futur système de la Nouvelle Agence Centrale

3. **Partenaires externes** :
   - RAFAM (Registre des Allocations Familiales)
   - CdC (UPI) : Centrale de Compensation
   - OFAS : Office Fédéral des Assurances Sociales
   - Autres Caisses : Autres caisses de compensation

### Flux de données existants et futurs

![Cartographie des flux de données Sedex](images/cartographie_flux_sedex.png)

La cartographie illustre les flux de données existants (lignes continues) et futurs (lignes pointillées) entre les différentes entités. Elle met en évidence la duplication des flux pendant la période de transition, où les deux agences (existante et nouvelle) devront gérer en parallèle les mêmes types d'échanges avec des SedexID différents.

### Implications pour la gestion des SedexID

La cartographie met en évidence plusieurs implications importantes :

1. **Duplication des flux** : Si les deux agences coexistent pendant une période de transition, les mêmes types de flux devront être gérés en parallèle.
2. **Redirection des messages** : Les partenaires externes devront être informés des changements de SedexID.
3. **Continuité de service** : La transition doit garantir qu'aucun message n'est perdu.
4. **Historique des échanges** : L'accès à l'historique doit être maintenu, même si le SedexID change.

### Comparaison des options de migration

![Comparaison des options de migration](images/comparaison_options_migration.png)

La comparaison visuelle des quatre options de migration met en évidence les avantages et inconvénients de chaque approche. L'Option 3 (création d'un nouveau SedexID) apparaît comme la plus adaptée, offrant un bon équilibre entre flexibilité de migration et clarté organisationnelle.

## Plan de migration détaillé

### Vue d'ensemble de la migration

La migration sera organisée en trois phases principales :

- **Phase 1 : Préparation** - Configuration technique et administrative (T1-T2 2025)
- **Phase 2 : Migration incrémentale** - Transfert progressif des affiliés (T3 2025 - T1 2026)
- **Phase 3 : Finalisation** - Intégration complète et stabilisation (T2-T3 2026)

### Phase 1 : Préparation (T1-T2 2025)

#### Jalon 1.1 : Configuration administrative (T1 2025, Semaines 1-6)
- Demande officielle d'un nouveau SedexID auprès de l'OFAS
- Préparation des documents administratifs
- Notification préliminaire aux partenaires

#### Jalon 1.2 : Configuration technique initiale (T1 2025, Semaines 7-12)
- Installation et configuration d'une nouvelle instance d'iPension/WebAVS
- Configuration du nouveau SedexID
- Tests de connectivité basiques

#### Jalon 1.3 : Tests d'intégration (T2 2025, Semaines 1-6)
- Tests d'intégration avec le RAFAM et la CdC
- Validation des formats d'échange et des routages

#### Jalon 1.4 : Préparation de la migration des données (T2 2025, Semaines 7-12)
- Développement des scripts et outils de migration
- Tests de migration sur un échantillon représentatif
- Finalisation du plan de migration incrémentale

### Phase 2 : Migration incrémentale (T3 2025 - T1 2026)

#### Jalon 2.1 : Préparation du premier lot de migration (T3 2025, Semaines 1-4)
- Sélection du premier lot d'affiliés (10% du total)
- Communication ciblée aux affiliés concernés

#### Jalon 2.2 : Migration du premier lot (T3 2025, Semaines 5-8)
- Exécution de la migration des données
- Notification au RAFAM des changements d'affiliation
- Surveillance intensive des échanges Sedex

#### Jalons 2.3 à 2.6 : Migration des lots suivants
- Évaluation et ajustements après chaque lot
- Migration progressive des lots restants (20%, 30%, 40%)

### Phase 3 : Finalisation et stabilisation (T2-T3 2026)

#### Jalon 3.1 : Vérification complète post-migration (T2 2026, Semaines 1-4)
- Audit complet des données migrées
- Vérification de la cohérence des échanges Sedex

#### Jalon 3.2 : Intégration des autres prestations (T2 2026, Semaines 5-12)
- Extension du périmètre fonctionnel à d'autres prestations

#### Jalon 3.3 : Désactivation de l'ancien SedexID (T3 2026, Semaines 1-6)
- Vérification préalable de l'absence d'échanges en cours
- Procédure de désactivation de l'ancien SedexID

#### Jalon 3.4 : Bilan et clôture du projet (T3 2026, Semaines 7-12)
- Évaluation complète du projet
- Clôture officielle du projet

### Matrice RACI et dépendances critiques

Le plan identifie clairement les responsabilités pour chaque jalon et les dépendances critiques qui doivent être gérées avec attention, notamment l'obtention du nouveau SedexID et la coordination avec le RAFAM.

## Plan de retour en arrière

### Principes généraux du plan de retour en arrière

Le plan de retour en arrière repose sur plusieurs principes fondamentaux :

1. **Préservation des données** : Sauvegarde de toutes les données originales avant chaque opération
2. **Réversibilité des actions** : Possibilité d'annuler chaque action jusqu'à un certain point
3. **Identification des points de non-retour** : Identification claire des étapes irréversibles
4. **Procédures documentées** : Documentation détaillée et tests préalables
5. **Responsabilités définies** : Rôles et responsabilités clairement établis

### Identification des points de non-retour

Trois points de non-retour critiques sont identifiés :

1. **Désactivation de l'ancien SedexID** (Phase 3, Jalon 3.3)
2. **Migration du lot final** (Phase 2, Jalon 2.6)
3. **Notification officielle aux partenaires** (Phase 1, Jalon 1.1)

### Plan de retour en arrière par phase

Pour chaque phase et jalon, le plan définit :
- Les sauvegardes préalables nécessaires
- Les procédures détaillées de retour en arrière
- Les délais maximums pour la décision
- Les responsables de la décision et de l'exécution

### Critères de déclenchement du retour en arrière

Des critères précis sont définis pour déclencher un retour en arrière, tant sur le plan technique (perte de données, dysfonctionnement des échanges) que métier (impact sur les versements, non-conformité réglementaire).

### Procédure de décision et tests

Le plan établit une procédure claire pour la prise de décision et prévoit des tests réguliers pour garantir l'efficacité des procédures de retour en arrière.

## Procédures manuelles temporaires

### Objectifs des procédures manuelles

Les procédures manuelles temporaires visent à :

1. **Assurer la continuité de service** : Garantir que les allocations sont traitées sans interruption
2. **Maintenir la conformité réglementaire** : Respecter les obligations légales
3. **Sécuriser les échanges critiques** : Prioriser les échanges les plus importants
4. **Faciliter la transition** : Permettre une migration progressive sans impact

### Identification des échanges critiques

Quatre types d'échanges sont identifiés comme critiques et nécessitent des procédures manuelles de secours :

1. **Annonces au RAFAM** : Très haute criticité, délai maximal acceptable de 24 heures
2. **Vérifications de droit auprès du RAFAM** : Haute criticité, délai maximal de 48 heures
3. **Vérifications des numéros AVS** : Criticité moyenne, délai maximal de 72 heures
4. **Transferts de dossiers entre caisses** : Criticité moyenne, délai maximal d'une semaine

### Procédures manuelles par type d'échange

Pour chaque type d'échange critique, le plan définit :
- Les conditions de déclenchement de la procédure manuelle
- Les formulaires standardisés à utiliser
- Le processus détaillé d'envoi et de traitement
- Les mécanismes de suivi et de régularisation

### Organisation et responsabilités

Une équipe spécifique sera constituée pour gérer les procédures manuelles, avec des horaires étendus pendant les périodes critiques de migration.

### Formation, documentation et outils

Le plan prévoit une formation complète du personnel, une documentation détaillée et des outils spécifiques pour faciliter la mise en œuvre des procédures manuelles.

## Identification des périodes critiques

### Analyse des cycles métier des Allocations Familiales

Les Allocations Familiales suivent plusieurs cycles métier qui influencent le choix des périodes de migration :

1. **Cycle mensuel de versement** : Préparation (15-20), génération des ordres (20-25), transmission (25-27), versement (1-5), traitement des anomalies (5-10)
2. **Cycle annuel des adaptations légales** : Annonce (sept-oct), paramétrage (nov-déc), entrée en vigueur (1er jan), régularisations (jan-fév)
3. **Cycle fiscal et statistique** : Certificats annuels (jan), statistiques trimestrielles, rapport annuel (31 mars)
4. **Cycle des contrôles d'employeurs** : Planification (jan), exécution (fév-nov), finalisation (nov-déc)

### Événements spécifiques à forte charge

Plusieurs événements génèrent une charge exceptionnelle :
- **Rentrée scolaire** : Mi-août à mi-octobre
- **Fin d'apprentissage/études** : Mi-mai à fin juillet
- **Indexations des allocations** : Variable selon les cantons

### Périodes critiques pour les échanges Sedex

L'analyse révèle des périodes de forte intensité d'échanges :
- **Échanges RAFAM** : Août-Octobre et Janvier
- **Échanges CdC** : Septembre-Octobre et Janvier-Février
- **Échanges OFAS** : Janvier-Mars et premières semaines de chaque trimestre

### Synthèse des périodes à éviter

#### Périodes à éviter absolument
1. **Décembre à mi-février** : Adaptations légales, clôture d'année
2. **20 du mois au 10 du mois suivant** : Cycle de versement mensuel
3. **Mi-août à mi-octobre** : Rentrée scolaire
4. **Mi-mai à fin juillet** : Fin d'études/apprentissage

### Fenêtres optimales pour la migration

Le plan identifie les fenêtres optimales pour chaque phase et lot de migration, recommandant notamment :
- **Phase 1** : Mars-Avril 2025
- **Migrations de lots** : Entre le 11 et le 14 de chaque mois (période la plus calme)
- **Finalisation** : Avant décembre 2026

### Calendrier de migration recommandé

Un calendrier optimal est proposé, tenant compte de toutes les contraintes identifiées et maximisant les chances de succès de la migration.

## Recommandations finales

### Choix de l'option de migration

Sur la base de l'analyse complète, l'**Option 3** (création d'un nouveau SedexID) est recommandée pour les raisons suivantes :

1. Elle permet une **séparation claire** entre l'ancienne et la nouvelle structure.
2. Elle offre la possibilité d'une **migration incrémentale** dès la Phase 2.
3. Elle **simplifie les échanges avec le RAFAM** en établissant une distinction nette.
4. Elle permet de **gérer en parallèle** les deux structures pendant la transition.

### Calendrier recommandé

Le calendrier optimal pour la migration est le suivant :

| Phase | Étape | Période recommandée |
|-------|-------|---------------------|
| Phase 1 | Configuration administrative | Mars-Avril 2025 |
| Phase 1 | Configuration technique | Mai-Juin 2025 |
| Phase 1 | Tests d'intégration | Juin-Juillet 2025 |
| Phase 1 | Préparation migration | Août-Septembre 2025 |
| Phase 2 | Migration Lot 1 (10%) | 11-14 novembre 2025 |
| Phase 2 | Évaluation et ajustements | Décembre 2025 |
| Phase 2 | Migration Lot 2 (20%) | 11-14 mars 2026 |
| Phase 2 | Migration Lot 3 (30%) | 11-14 avril 2026 |
| Phase 2 | Migration Lot 4 (40%) | 11-14 mai 2026 |
| Phase 3 | Vérification complète | Juin 2026 |
| Phase 3 | Intégration autres prestations | Juillet-Septembre 2026 |
| Phase 3 | Désactivation ancien SedexID | Octobre-Novembre 2026 |
| Phase 3 | Bilan et clôture | Novembre-Décembre 2026 |

### Mesures d'accompagnement essentielles

Pour garantir le succès de la migration, les mesures d'accompagnement suivantes sont recommandées :

1. **Coordination étroite avec le RAFAM** : Établir un canal de communication privilégié et des points de contact dédiés.

2. **Tests approfondis avant chaque lot de migration** : Réaliser des tests de bout en bout pour chaque scénario d'échange.

3. **Formation intensive du personnel** : Former toutes les équipes concernées aux nouvelles procédures et aux procédures manuelles de secours.

4. **Communication transparente avec les affiliés** : Informer les affiliés des changements à venir et des impacts potentiels.

5. **Surveillance renforcée pendant les périodes de migration** : Mettre en place un monitoring en temps réel des échanges Sedex.

6. **Équipe de support dédiée** : Constituer une équipe spécifique pour traiter rapidement les incidents pendant la migration.

7. **Documentation exhaustive** : Maintenir une documentation à jour de toutes les procédures et configurations.

### Gouvernance du projet

Une structure de gouvernance claire est recommandée :

1. **Comité de pilotage** : Direction de la caisse, responsables métiers, représentants IT
2. **Direction de projet** : Responsable dédié avec autorité sur toutes les équipes impliquées
3. **Comité technique** : Experts IT, Sedex et métier
4. **Équipe de coordination externe** : Liaison avec RAFAM, CdC, OFAS

### Indicateurs de suivi

Les indicateurs suivants devraient être suivis tout au long du projet :

1. **Taux de réussite des migrations** : Pourcentage de dossiers migrés sans anomalie
2. **Continuité de service** : Pourcentage d'échanges Sedex traités avec succès
3. **Respect du calendrier** : Écart entre dates planifiées et réelles
4. **Satisfaction des utilisateurs** : Évaluation régulière
5. **Impact sur les affiliés** : Nombre d'incidents ou réclamations

## Conclusion

La fusion des caisses de compensation et la migration des identifiants Sedex représentent un défi technique et organisationnel majeur, particulièrement dans le contexte sensible des Allocations Familiales. Ce rapport a présenté une analyse approfondie de la situation et proposé une stratégie complète pour mener à bien cette transition.

L'Option 3 (création d'un nouveau SedexID) apparaît comme la solution optimale, offrant un équilibre entre flexibilité de migration et clarté organisationnelle. Le plan de migration détaillé, échelonné sur trois phases, permet une transition progressive et sécurisée, avec des jalons clairement définis.

Les procédures manuelles temporaires et le plan de retour en arrière constituent des filets de sécurité essentiels pour garantir la continuité des services en toutes circonstances. L'identification des périodes critiques et des fenêtres optimales de migration permet d'optimiser le calendrier du projet et de minimiser les risques.

La mise en œuvre de ces recommandations, combinée à une gouvernance solide et à un suivi rigoureux, permettra de réaliser cette fusion avec un impact minimal sur les affiliés et les bénéficiaires des allocations familiales.

## Annexes

### Annexe 1 : Glossaire des termes techniques

- **Sedex** : Secure Data Exchange, infrastructure nationale suisse d'échange sécurisé de données
- **SedexID** : Identifiant unique attribué à chaque participant au réseau Sedex
- **RAFAM** : Registre des Allocations Familiales
- **CdC** : Centrale de Compensation
- **UPI** : Unique Person Identification, système de gestion des numéros AVS
- **OFAS** : Office Fédéral des Assurances Sociales
- **iPension/WebAVS** : Systèmes informatiques utilisés par les caisses de compensation

### Annexe 2 : Références documentaires

- Directives techniques Sedex de l'OFAS
- Normes eCH pour les échanges de données (eCH-0058, eCH-0085)
- Documentation technique iPension/WebAVS
- Réglementation sur les allocations familiales

### Annexe 3 : Liste des documents produits

1. Analyse du contexte de fusion des caisses de compensation
2. Documentation des flux de données Sedex existants
3. Cartographie des échanges de données
4. Plan de migration détaillé
5. Plan de retour en arrière
6. Procédures manuelles temporaires
7. Identification des périodes critiques

### Annexe 4 : Visualisations

- Cartographie des flux de données Sedex
- Comparaison des options de migration
- Calendrier de migration recommandé
- Matrice des responsabilités (RACI)
